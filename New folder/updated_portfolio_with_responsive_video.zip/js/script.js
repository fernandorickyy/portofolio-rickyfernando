// Main script (DOMContentLoaded)
document.addEventListener('DOMContentLoaded', () => {
    const preloader = document.getElementById('preloader');
    const rocketContainer = document.querySelector('.rocket-container');
    const rocket = document.querySelector('.rocket-svg');
    const clickToLaunch = document.getElementById('clickToLaunch');
    const mainContent = document.getElementById('main-content');
    const menuToggle = document.getElementById('menu-toggle');
    const overlayMenu = document.getElementById('overlay-menu');
    const closeMenu = document.getElementById('close-menu');
    const menuLinks = document.querySelectorAll('.overlay-menu nav ul li a');
    const sections = document.querySelectorAll('.section');
    const homeSlides = document.querySelectorAll('.home-slider .slide');
    const sliderDots = document.querySelectorAll('.slider-controls .slider-dot');
    const flameContainer = document.getElementById('flame-container');
    const smokeContainer = document.getElementById('smoke-container');
    const bgVideo = document.getElementById('bg-video');
    const muteToggle = document.getElementById('video-mute-toggle');

    let currentSlide = 0;
    let slideInterval;
    let isLaunching = false;

    // Respect reduced-motion preference
    const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // ------------------ Video source selection & helpers ------------------
    function supportsWebM() {
        try {
            const v = document.createElement('video');
            return !!(v.canPlayType && (v.canPlayType('video/webm; codecs="vp8, vorbis"') || v.canPlayType('video/webm; codecs="vp9"') || v.canPlayType('video/webm')));
        } catch (e) { return false; }
    }

    function prefersReducedMotion() {
        return window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }

    function getNetworkHints() {
        const nav = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
        const info = { saveData: false, effectiveType: null };
        if (nav) {
            info.saveData = !!nav.saveData;
            info.effectiveType = nav.effectiveType || null;
        }
        return info;
    }

    function chooseVideoVariant() {
        const isMobileWidth = window.matchMedia('(max-width: 768px)').matches;
        const network = getNetworkHints();
        if (prefersReducedMotion()) return null;
        const slowNet = (network.saveData || (network.effectiveType && /2g/.test(network.effectiveType)));
        const sizeKey = (isMobileWidth || slowNet) ? '640' : '1280';
        return sizeKey;
    }

    function buildSourcesForVideo(videoEl) {
        if (!videoEl) return;
        const files = {
            '1280': {
                webm: 'assets/videos/electrons_720_vp8_crf10.webm',
                mp4:  'assets/videos/electrons_compressed_720_crf30.mp4'
            },
            '640': {
                webm: 'assets/videos/electrons_640_vp8_crf10.webm',
                mp4:  'assets/videos/electrons_compressed_640_crf30.mp4'
            }
        };

        const preferWebM = supportsWebM();
        const sizeKey = chooseVideoVariant();
        if (!sizeKey) {
            videoEl.pause();
            videoEl.style.display = 'none';
            return;
        }

        while (videoEl.firstChild) videoEl.removeChild(videoEl.firstChild);

        const order = preferWebM ? ['webm','mp4'] : ['mp4','webm'];
        order.forEach(format => {
            const src = files[sizeKey][format];
            if (!src) return;
            const sourceEl = document.createElement('source');
            sourceEl.src = src;
            sourceEl.type = (format === 'webm') ? 'video/webm' : 'video/mp4';
            sourceEl.setAttribute('data-variant', sizeKey);
            videoEl.appendChild(sourceEl);
        });

        videoEl.load();
        const p = videoEl.play();
        if (p !== undefined) {
            p.catch(err => {
                videoEl.muted = true;
                videoEl.play().catch(e => {
                    console.warn('Autoplay blocked for background video.', e);
                });
            });
        }
    }

    function tryPauseVideo() { if (bgVideo) { try { bgVideo.pause(); } catch(e){} } }
    function tryPlayVideo() { if (bgVideo) { try { const p = bgVideo.play(); if (p !== undefined) p.catch(()=>{ bgVideo.muted = true; bgVideo.play().catch(()=>{}); }); } catch(e){} } }

    // Setup mute toggle
    function updateMuteButtonUI() {
        if (!muteToggle || !bgVideo) return;
        const pressed = bgVideo && !bgVideo.muted;
        muteToggle.setAttribute('aria-pressed', String(pressed));
        muteToggle.title = pressed ? 'Unmute background video' : 'Mute background video';
        // show/hide icons accordingly
        const svgs = muteToggle.querySelectorAll('svg');
        if (svgs.length >= 2) {
            if (bgVideo.muted) { svgs[0].style.display = 'none'; svgs[1].style.display = 'block'; }
            else { svgs[0].style.display = 'block'; svgs[1].style.display = 'none'; }
        }
    }

    if (muteToggle) {
        muteToggle.addEventListener('click', (e) => {
            e.preventDefault();
            if (!bgVideo) return;
            // toggle mute
            bgVideo.muted = !bgVideo.muted;
            // persist preference in localStorage
            try { localStorage.setItem('bgVideoMuted', bgVideo.muted ? '1' : '0'); } catch(e){}
            updateMuteButtonUI();
            // if unmuting, ensure video is playing
            if (!bgVideo.muted) tryPlayVideo();
        });
    }

    // Initialize muted state from storage
    try { const stored = localStorage.getItem('bgVideoMuted'); if (stored !== null && bgVideo) { bgVideo.muted = stored === '1'; } } catch(e){}

    // ============================================================
    // FLAME & SMOKE (unchanged but included)
    // ============================================================
    const createFlame = () => { if (!isLaunching) return; const flame = document.createElement('div'); flame.className = 'flame'; flameContainer.appendChild(flame); setTimeout(()=>{ flame.remove(); }, 800); };
    const createSmoke = () => { if (!isLaunching) return; const smoke = document.createElement('div'); smoke.className = 'smoke'; smokeContainer.appendChild(smoke); setTimeout(()=>{ smoke.classList.add('active'); }, 10); setTimeout(()=>{ smoke.remove(); }, 2000); };
    const startLaunchEffects = () => { isLaunching = true; let effectCount = 0; const effectInterval = setInterval(()=>{ createFlame(); createSmoke(); effectCount++; if (effectCount >= 15) clearInterval(effectInterval); }, 100); };

    if (rocketContainer && preloader) {
        rocketContainer.addEventListener('click', () => {
            clickToLaunch.style.display = 'none';
            rocket.style.animation = 'none';
            startLaunchEffects();
            setTimeout(()=>{ rocketContainer.classList.add('rocket-launching'); isLaunching = false; }, 2500);
            setTimeout(()=>{
                preloader.style.opacity = '0'; preloader.style.visibility = 'hidden'; mainContent.classList.remove('hidden'); document.body.style.overflowY = 'auto'; setActiveSection('home'); startAutoSlide();
                // Build sources and play
                buildSourcesForVideo(bgVideo);
                // make sure UI matches mute state
                updateMuteButtonUI();
            }, 10000);
        });
    }

    // ============================================================
    // SECTION ACTIVATION & MENU
    // ============================================================
    const setActiveSection = (sectionId) => {
        sections.forEach(section => { if (section.id === sectionId) { section.classList.add('active'); section.classList.remove('hidden'); } else { section.classList.remove('active'); section.classList.add('hidden'); } });
        menuLinks.forEach(link => { link.classList.remove('active-menu-link'); if (link.dataset.section === sectionId) link.classList.add('active-menu-link'); });
        if (sectionId === 'home') tryPlayVideo(); else tryPauseVideo();
    };

    if (menuToggle && overlayMenu && closeMenu) {
        menuToggle.addEventListener('click', ()=>{ overlayMenu.classList.add('active'); document.body.style.overflow = 'hidden'; });
        closeMenu.addEventListener('click', ()=>{ overlayMenu.classList.remove('active'); document.body.style.overflow = 'auto'; });
        menuLinks.forEach(link => { link.addEventListener('click', (e)=>{ e.preventDefault(); const targetSectionId = link.dataset.section; setActiveSection(targetSectionId); overlayMenu.classList.remove('active'); document.body.style.overflow = 'auto'; const targetSection = document.getElementById(targetSectionId); if (targetSection) targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' }); }); });
    }

    // ============================================================
    // HOME SLIDER
    // ============================================================
    const showSlide = (index) => { homeSlides.forEach((slide,i)=>{ if (i===index) slide.classList.add('active'); else slide.classList.remove('active'); }); sliderDots.forEach((d,i)=>{ d.classList.toggle('active', i===index); }); };
    const nextSlide = () => { currentSlide = (currentSlide+1) % homeSlides.length; showSlide(currentSlide); };
    const startAutoSlide = () => { if (slideInterval) clearInterval(slideInterval); slideInterval = setInterval(nextSlide, 5000); };
    sliderDots.forEach((dot, index) => { dot.addEventListener('click', ()=>{ currentSlide = index; showSlide(currentSlide); clearInterval(slideInterval); startAutoSlide(); }); });

    // Initial setup
    mainContent.classList.add('hidden'); document.body.style.overflow = 'hidden'; showSlide(currentSlide); if (bgVideo) tryPauseVideo();

    // Re-evaluate video sources on resize and network change
    let resizeTimer;
    window.addEventListener('resize', ()=>{ clearTimeout(resizeTimer); resizeTimer = setTimeout(()=> buildSourcesForVideo(bgVideo), 250); });
    const navConn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    if (navConn && typeof navConn.addEventListener === 'function') {
        try { navConn.addEventListener('change', ()=> buildSourcesForVideo(bgVideo)); } catch(e){}
    }

    // Intersection observer to resume video when home visible & active
    const observer = new IntersectionObserver(entries => { entries.forEach(entry => { if (entry.isIntersecting && entry.target.id === 'home' && entry.target.classList.contains('active')) tryPlayVideo(); }); }, { threshold: 0.5 });
    const homeSection = document.getElementById('home'); if (homeSection) observer.observe(homeSection);

    // Set initial mute button UI
    updateMuteButtonUI();
});
